$(document).ready(function ($) {
    if($(window).width()>1200){
    var height = $('.container-fluid').height();
        $('.list-group').height((height - 100) + 'px');
        $('.list-group').css('overflow', 'scroll');
        $('.panel-default').css('position', 'fixed');
        $('.panel-default').css('width', '23%');
    }else{
        $('#nav').css('display','none');
        $('#box').mouseenter(function(){
           $('#nav').toggle("slow"); 
        });
        $('#box').mouseleave(function(){
           $('#nav').toggle("slow"); 
        });
        $('.panel-body').css('padding',0);
        $('.container-fluid').css('padding',0);
        $('.col-md-9').css('padding',0);
    }

    $('a.ajax').click(function (e) {
        e.preventDefault();
        var offset = $(this).attr('data-offset');
		var index = $(this).attr('data-index');
        $.ajax({
            url: 'getLocation.php',
            method: 'POST',
            data: {'offset': offset, 'index' : index},
            success: function (html) {
                $('#main-right').html(html);
            }});
    });
    $('a.ajax').click(function(e){
        $('.targeted').removeClass('targeted');
        $(this).addClass('targeted');
    });
    $('#box').instaFilta();
});
$(document).ready(function(){
   var nr_locatii = $('#nr_locatii').attr('data-max');
   $('#locatii_disp').html(' ('+ nr_locatii + ' locatii)');
});
