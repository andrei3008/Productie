<?php
require_once('includes/dbConnect.php');
if (!isset($_SESSION['database'])) {
    header('location:index.php');
}
if(isset($_GET['offset'])){
    $invalid_characters = array("$", "%", "#", "<", ">", "|");
    $offset = str_replace($invalid_characters, "", $_GET['offset']);
    $selectedItem = $_GET['offset']+1;
}else{
    $offset = 0;
    $selectedItem = 1;
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Main Page</title>
        <?php require_once('includes/header.php'); ?>
    </head>
    <body>
        <div class="container-fluid">
            <div class="col-lg-12">
                <p class="right">Sunteti logat ca utilizatorul <?php echo $_SESSION['username'] ?>.<a href="logout.php">[Logout]</a></p>
            </div>
            <div class="col-md-3">
                <div class="panel panel-default">
                    <div class="panel-heading">Locatii disponibile <span class="highlighted"><?php echo $_SESSION['username'] ?><spane id="locatii_disp"></spane></span></div>
                    <ul class="search">
                        <li><input type="text" id="box" name="search" class="form-control" placeholder="Cauta Locatie"></li>
                    </ul>
                    <ul class="list-group" id="nav">
                        <?php
                        $con->select_db($_SESSION['database']);
                        if ($result = $con->query('SELECT firme.denumire, locatii.idfirma,locatii.idlocatie FROM ' . $_SESSION['database'] . '.locatii INNER JOIN ' . $_SESSION['database'] . '.firme ON locatii.idfirma=firme.idfirma WHERE locatii.idlocatie<>0 ORDER BY locatii.idlocatie;')) {
                            $i = 0; 
                            while ($obj = $result->fetch_object()) {
                                ?>
                        <li class="list-group-item instafilta-target"><a href="#" data-offset="<?php echo $i; $i++;  ?>" data-index="<?php echo $i; ?>" class="ajax <?php echo 'current'; ?>"><?php echo $i.'. '.$obj->denumire; ?></a></li>
                                <?php
                            }
                         ?><input type="hidden" name="nr_locatii" id="nr_locatii" data-max="<?php echo $i; ?>"><?php
                        }
                        ?>
                    </ul>
                </div>
            </div>
            <div class="col-md-9">
                <div class="panel panel-primary" id="main-right">
                    <div class="panel-heading">Lista detaliata locatii</div>
                    <?php
                    if ($resultDetalii = $con->query('SELECT '
                            . 'firme.denumire,'
                            . ' locatii.idfirma,'
                            . ' locatii.localitate,'
                            . ' locatii.idlocatie,'
                            . ' locatii.adresa FROM ' . $_SESSION['database'] . '.locatii INNER JOIN ' . $_SESSION['database'] . '.firme ON locatii.idfirma=firme.idfirma WHERE locatii.idlocatie <> 0  ORDER BY locatii.idlocatie LIMIT '.$offset.',5 ;')) {
                        $k = 1;
						while ($objDetalii = $resultDetalii->fetch_object()) {
                            ?>
                            <div class="panel panel-info">
                                <div class="panel-heading"><?php echo '<h4 class="'.(($k==1) ? 'orange' : '').'">'.$k. '. ' . $objDetalii->denumire . '</h4> ' . $objDetalii->adresa; $k++; ?></div>
                                <div class="panel-body">
                                    <?php
                                    $query = 'SELECT 
                                        aparate.idAparat,
                                        aparate.seria,
                                        aparate.tip,
                                        aparate.pozitieLocatie,
                                        stareaparate.lastIdxInM,
                                        stareaparate.lastIdxOutM,
                                        stareaparate.ultimaConectare
                                        FROM ' . $_SESSION['database'] . '.aparate INNER JOIN ' . $_SESSION['database'] . '.stareaparate ON aparate.idAparat = stareaparate.idAparat WHERE aparate.idLocatie="' . $objDetalii->idlocatie . '"';
                                    if ($resultAparate = $con->query($query)) {
                                        ?>
                                        <table class="table-bordered table-striped table-condensed cf table-responsive">
                                            <thead>
                                                <tr>
                                                    <th>Poz Loc</th>
                                                    <th>Seria</th>
                                                    <th>Tip</th>
                                                    <th>Contor IN</th>
                                                    <th>Contor OUT</th>
                                                    <th>Ultima accesare</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            <?php 
                                                $i=1;
                                                while($objAparate = $resultAparate->fetch_object()){
                                            ?>
                                                <tr>
                                                    <td><?php echo $objAparate->pozitieLocatie; ?></td>
                                                    <td><?php echo $objAparate->seria; ?></td>
                                                    <td><?php echo ($objAparate->tip == -1) ? '' : $objAparate->tip; ?></td>
                                                    <td><?php echo $objAparate->lastIdxInM; ?></td>
                                                    <td><?php echo $objAparate->lastIdxOutM; ?></td>
                                                    <td><?php echo $objAparate->ultimaConectare; ?></td>
                                                </tr>
                                            <?php
                                                }
                                            ?>
                                            </tbody>
                                        </table>
                                    <div class="col-md-12">
                                        <a href="raportzilnic.php?id=<?php echo $objDetalii->idlocatie; ?>" class="btn btn-primary btn-md right rapoarte">Raport Zilnic</a>
                                        <a href="raportlunar.php?id=<?php echo $objDetalii->idlocatie; ?>" class="btn btn-primary btn-md right rapoarte">Raport Lunar</a>
                                    </div>
                                        <?php
                                    }
                                    ?>
                                </div>
                            </div>
                            <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
    </body>
</html>
