<!DOCTYPE>
<?php 
require_once('includes/dbConnect.php');
if(isset($_SESSION['database'])){
    header('location:main.php');
}
$con->select_db('operatori');
if (isset($_POST['go'])) {
    $invalid_characters = array("$", "%", "#", "<", ">", "|");
    $username = str_replace($invalid_characters, "", $_POST['user']);
    if ($result = $con->query('SELECT * FROM operatori.operatori WHERE user="' . $username . '"')) {
        while ($obj = $result->fetch_object()) {
            if($obj->pass == $_POST['pass']){
                $_SESSION['username'] = $username;
                $_SESSION['database'] = $obj->denBaza;
                header('location:main.php');
            }else {
                $rezultat = "Username sau parola gresita";
            }
        }
    }
}
?>
<html>
    <head>
        <?php require_once('includes/header.php'); ?>
        <link rel="stylesheet" type="text/css" href="css/loginStyle.css"/>
        <script type="text/javascript" src="js/login.js"></script>
    </head>
    <body>
        <div class="container">

            <div class="row" id="pwd-container">
                <div class="col-md-4"></div>

                <div class="col-md-4">
                    <section class="login-form">
                        <form method="post" role="login">
                            <img src="http://i.imgur.com/RcmcLv4.png" class="img-responsive" alt="" />

                            <input type="text" name="user" placeholder="User Name" required class="form-control input-lg" />

                            <input type="password" class="form-control input-lg" id="password" placeholder="Password" required="" name="pass" />
                            <?php
                            if(isset($result)){
                            ?>
                            <ul class="error-list">
                                <li class="red"><?php echo $rezultat; ?></li>
                            </ul>
                            <?php
                            }
                            ?>

                            <div class="pwstrength_viewport_progress"></div>


                            <button type="submit" name="go" class="btn btn-lg btn-primary btn-block">Logare</button>
                            <div>
                            </div>

                        </form>

                        <div class="form-links">
                            <a href="#">red77.ro</a>
                        </div>
                    </section>  
                </div>

                <div class="col-md-4"></div>


            </div> 

        </div>
    </body>
</html>