<?php
require_once('includes/dbConnect.php');
if (!isset($_SESSION['database'])) {
    header('location:index.php');
}
?>
<div class = "panel-heading">Lista detaliata locatii</div>
<?php
if ($resultDetalii = $con->query('SELECT '
        . 'firme.denumire,'
        . ' locatii.idfirma,'
        . ' locatii.localitate,'
        . ' locatii.idlocatie,'
        . ' locatii.adresa FROM ' . $_SESSION['database'] . '.locatii INNER JOIN ' . $_SESSION['database'] . '.firme ON locatii.idfirma=firme.idfirma WHERE locatii.idlocatie<>0 ORDER BY locatii.idlocatie  LIMIT ' . $_POST['offset'] . ',5;')) {
    $index = $_POST['index'];
	while ($objDetalii = $resultDetalii->fetch_object()) {
        ?>
        <div class="panel panel-info <?php echo ($index==$_POST['index']) ? 'çurrent' : ''; ?>" data-cur="<?php echo ($index == $_POST['index']) ? $index : ''; ?>" >
            <div class="panel-heading"><?php echo '<h4 class="'.(($index == $_POST['index']) ? 'orange' : '').'">'.$index.'. ' . $objDetalii->denumire . '</h4> ' . $objDetalii->adresa; $index++; ?></div>
            <div class="panel-body">
                <?php
                $query = 'SELECT 
                                        aparate.idAparat,
                                        aparate.seria,
                                        aparate.tip,
                                        aparate.pozitieLocatie,
                                        stareaparate.lastIdxInM,
                                        stareaparate.lastIdxOutM,
                                        stareaparate.ultimaConectare
                                        FROM ' . $_SESSION['database'] . '.aparate INNER JOIN ' . $_SESSION['database'] . '.stareaparate ON aparate.idAparat = stareaparate.idAparat WHERE aparate.idLocatie="' . $objDetalii->idlocatie . '"';
                if ($resultAparate = $con->query($query)) {
                    ?>
                    <table class="table-bordered table-striped table-condensed cf col-md-12">
                        <thead>
                            <tr>
                                <th>Poz Loc</th>
                                <th>Seria</th>
                                <th>Tip</th>
                                <th>Contor IN</th>
                                <th>Contor OUT</th>
                                <th>Ultima accesare</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $i = 1;
                            while ($objAparate = $resultAparate->fetch_object()) {
                                ?>
                                <tr>
                                    <td><?php echo $objAparate->pozitieLocatie; ?></td>
                                    <td><?php echo $objAparate->seria; ?></td>
                                    <td><?php echo ($objAparate->tip == -1) ? '' : $objAparate->tip; ?></td>
                                    <td><?php echo $objAparate->lastIdxInM; ?></td>
                                    <td><?php echo $objAparate->lastIdxOutM; ?></td>
                                    <td><?php echo $objAparate->ultimaConectare; ?></td>
                                </tr>
                                <?php
                            }
                            ?>
                        </tbody>
                    </table>
                    <div class="col-md-12">
                        <a href="raportzilnic.php?id=<?php echo $objDetalii->idlocatie; ?>" class="btn btn-primary btn-md right rapoarte">Raport Zilnic</a>
                        <a href="raportlunar.php?<?php echo $objDetalii->idLocatie; ?>" class="btn btn-primary btn-md right rapoarte">Raport Lunar</a>
                    </div>
                    <?php
                }
                ?>
            </div>
        </div>
        <?php
    }
}
?>